
__asm__(".code16gcc");

#include "history.h"
#include "allocator.h"

static unsigned int max_size, cur_size;
static char_t *ll_start;

void history_init(int size){

    max_size = size;
    cur_size = 0;
    ll_start = NULL;
    
}

/*
 * Puts a character into the history buffer. The buffer
 * should be implemented as a FIFO queue.
 *
 * There is only a single consumer and producer, and hence
 * no race conditions, allowing for a very simple
 * implementation without locks.
 */
void history_put(char s){
}

void history_write(void){
}



